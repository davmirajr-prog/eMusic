/*
 * Audio para el modo osu!mania: síntesis de pista de acompañamiento y hitsounds.
 */
(function (root) {
  'use strict';

  let ctx = null;

  function getContext() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function toneAt(midi, startTime, duration, volume, type) {
    const ac = getContext();
    const freq = (root.MusicLogic || root.ManiaLogic).midiToFreq ? root.MusicLogic.midiToFreq(midi) : 440 * Math.pow(2, (midi - 69) / 12);
    const now = startTime;
    const gain = ac.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume || 0.25, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    gain.connect(ac.destination);

    const osc = ac.createOscillator();
    osc.type = type || 'triangle';
    osc.frequency.value = freq;
    osc.connect(gain);
    osc.start(now);
    osc.stop(now + duration + 0.05);
  }

  function noiseBurst(startTime, duration, volume, filterFreq) {
    const ac = getContext();
    const bufSize = ac.sampleRate * duration;
    const buf = ac.createBuffer(1, bufSize, ac.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < bufSize; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / bufSize);
    const src = ac.createBufferSource();
    src.buffer = buf;
    const filter = ac.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = filterFreq || 5000;
    const gain = ac.createGain();
    gain.gain.value = volume || 0.15;
    src.connect(filter).connect(gain).connect(ac.destination);
    src.start(startTime);
    src.stop(startTime + duration + 0.02);
  }

  function kickAt(startTime) {
    const ac = getContext();
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, startTime);
    osc.frequency.exponentialRampToValueAtTime(40, startTime + 0.18);
    gain.gain.setValueAtTime(0.0001, startTime);
    gain.gain.exponentialRampToValueAtTime(0.6, startTime + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.0001, startTime + 0.2);
    osc.connect(gain).connect(ac.destination);
    osc.start(startTime);
    osc.stop(startTime + 0.22);
  }

  function hatAt(startTime, open) {
    noiseBurst(startTime, open ? 0.12 : 0.04, open ? 0.12 : 0.08, open ? 6000 : 8000);
  }

  function scheduleBacking(chart, audioStart, bpm) {
    const beat = 60 / bpm;
    const last = chart.length ? chart[chart.length - 1].time : 45;
    const total = last + 3;

    // Melodía/pista a partir de las notas del chart.
    chart.forEach((n) => toneAt(n.midi, audioStart + n.time, 0.22, 0.18, 'triangle'));

    // Percusión.
    for (let t = 0; t < total; t += beat / 2) {
      const isBeat = Math.abs(t % beat) < 0.001;
      if (isBeat) {
        const measure = Math.floor(t / (beat * 4));
        kickAt(audioStart + t);
        if (measure % 2 === 0) kickAt(audioStart + t); // refuerzo
      } else {
        hatAt(audioStart + t, false);
      }
      // Charleston abierto en tiempos fuertes cada 2 compases.
      if (isBeat && (Math.round(t / beat) % 8 === 7)) hatAt(audioStart + t, true);
    }
  }

  function hitsound(judgment) {
    const ac = getContext();
    const now = ac.currentTime;
    const freq = { PERFECT: 880, GREAT: 740, GOOD: 620, BAD: 330, MISS: 0 }[judgment] || 660;
    if (judgment === 'MISS') {
      // thud
      const osc = ac.createOscillator();
      const g = ac.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(180, now);
      osc.frequency.exponentialRampToValueAtTime(60, now + 0.15);
      g.gain.setValueAtTime(0.3, now);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 0.18);
      osc.connect(g).connect(ac.destination);
      osc.start(now);
      osc.stop(now + 0.2);
      return;
    }
    const osc = ac.createOscillator();
    const g = ac.createGain();
    osc.type = 'square';
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.22, now + 0.005);
    g.gain.exponentialRampToValueAtTime(0.0001, now + 0.08);
    osc.connect(g).connect(ac.destination);
    osc.start(now);
    osc.stop(now + 0.1);
  }

  root.ManiaAudio = { getContext, scheduleBacking, hitsound, toneAt, midiToFreq: (m) => 440 * Math.pow(2, (m - 69) / 12) };
})(window);
