/*
 * Lógica pura del juego estilo osu!mania: juicios, puntuación y generación de charts.
 */
(function (root) {
  'use strict';

  const WINDOWS = { PERFECT: 0.05, GREAT: 0.10, GOOD: 0.15, BAD: 0.20 };
  const MISS_WINDOW = 0.25;
  const POINTS = { PERFECT: 300, GREAT: 200, GOOD: 100, BAD: 50, MISS: 0 };
  const HEALTH_DELTA = { PERFECT: 10, GREAT: 8, GOOD: 5, BAD: -5, MISS: -20 };

  // Notas MIDI para 1..11 carriles (escala de Do mayor extendida).
  const LANE_NOTES_LIST = [60, 62, 64, 65, 67, 69, 71, 72, 74, 76, 77];
  const LANE_NOTES = {};
  for (let i = 1; i <= 11; i++) LANE_NOTES[i] = LANE_NOTES_LIST.slice(0, i);

  // Patrón de carriles para un chart de 8 carriles (se repite).
  const LANE_PATTERN_8 = [0, 4, 1, 5, 2, 6, 3, 7, 0, 3, 4, 7, 1, 6, 2, 5];

  function judge(delta) {
    const d = Math.abs(delta);
    if (d <= WINDOWS.PERFECT) return { name: 'PERFECT', points: POINTS.PERFECT, delta: d };
    if (d <= WINDOWS.GREAT) return { name: 'GREAT', points: POINTS.GREAT, delta: d };
    if (d <= WINDOWS.GOOD) return { name: 'GOOD', points: POINTS.GOOD, delta: d };
    if (d <= WINDOWS.BAD) return { name: 'BAD', points: POINTS.BAD, delta: d };
    return { name: 'MISS', points: POINTS.MISS, delta: d };
  }

  function healthDelta(judgment) { return HEALTH_DELTA[judgment] || 0; }
  function clampHealth(h) { return Math.max(0, Math.min(100, h)); }

  function generateChart(opts) {
    opts = opts || {};
    const bpm = opts.bpm || 120;
    const duration = opts.duration || 45;
    const lanes = Math.max(1, Math.min(9, opts.lanes || 8));
    const laneNotes = LANE_NOTES[lanes];
    const start = (opts.startTime !== undefined) ? opts.startTime : 2.0;
    const rand = opts.rand || Math.random;
    const beat = 60 / bpm;
    const step = beat / 3; // corcheas con puntillo (triplets): densidad intermedia
    const notes = [];
    let id = 0;
    let prevLane = null;
    let prevPrevLane = null;
    for (let t = start; t < duration; t += step) {
      const index = Math.round((t - start) / step);
      // Pequeños silencios para respirar (poco frecuentes).
      if (rand() < 0.06) continue;

      const lanesToHit = new Set();
      let main;
      const roll = rand();
      if (prevLane !== null && roll < 0.34) {
        // Jack: misma tecla dos o más seguidas.
        main = prevLane;
      } else if (prevLane !== null && roll < 0.64 && lanes > 1) {
        // Stream escalonado: vecino cercano (trill).
        const dir = rand() < 0.5 ? 1 : -1;
        main = (prevLane + dir + lanes) % lanes;
        if (prevPrevLane !== null && rand() < 0.3) {
          main = (prevLane + (prevLane - prevPrevLane + lanes) % lanes) % lanes;
        }
      } else if (lanes > 1 && roll < 0.80) {
        // Salto mediano.
        const jump = 1 + Math.floor(rand() * Math.max(1, Math.floor(lanes / 2)));
        main = (prevLane !== null ? prevLane : 0) + (rand() < 0.5 ? jump : -jump);
        main = ((main % lanes) + lanes) % lanes;
      } else {
        // Nota aleatoria para romper el patrón.
        main = Math.floor(rand() * lanes);
      }
      lanesToHit.add(main);

      // Acordes (combinaciones de teclas) en tiempos fuertes o aleatorios.
      if (index % 4 === 0 && lanes > 1) {
        const extra = Math.floor(rand() * lanes);
        if (extra !== main) lanesToHit.add(extra);
        if (rand() < 0.50 && lanes > 2) {
          const extra2 = Math.floor(rand() * lanes);
          if (extra2 !== main && extra2 !== extra) lanesToHit.add(extra2);
        }
      } else if (lanes > 1 && rand() < 0.15) {
        // Doble ocasional fuera del strong beat (gallop feel).
        const extra = (main + 1) % lanes;
        lanesToHit.add(extra);
      }

      prevPrevLane = prevLane;
      prevLane = main;

      for (const lane of lanesToHit) {
        if (lane < 0 || lane >= lanes) continue;
        notes.push({
          id: id++,
          time: Number(t.toFixed(6)),
          lane,
          midi: laneNotes[lane],
        });
      }
    }

    notes.sort((a, b) => (a.time - b.time) || (a.lane - b.lane));
    return notes;
  }

  function accuracyPercent(totalPoints, noteCount) {
    if (!noteCount) return 100;
    const max = noteCount * 300;
    return Math.max(0, Math.min(100, (100 * totalPoints) / max));
  }

  const api = {
    WINDOWS, MISS_WINDOW, POINTS, HEALTH_DELTA, LANE_NOTES, LANE_PATTERN_8,
    judge, healthDelta, clampHealth, generateChart, accuracyPercent,
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.ManiaLogic = api;
})(typeof window !== 'undefined' ? window : globalThis);
