/*
 * Juego estilo osu!mania con música generada.
 */
(function () {
  'use strict';

  const L = window.ManiaLogic;
  const A = window.ManiaAudio;

  const canvas = document.getElementById('mania-canvas');
  const ctx2 = canvas.getContext('2d');

  const WIDTH = 480;
  const HEIGHT = 620;
  const DPR = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = WIDTH * DPR;
  canvas.height = HEIGHT * DPR;
  ctx2.setTransform(DPR, 0, 0, DPR, 0, 0);

  const JUDGMENT_Y = 520;
  const APPROACH_TIME = 0.45; // velocidad más suave
  const NOTE_SPEED = (JUDGMENT_Y - 40) / APPROACH_TIME;
  const NOTE_HEIGHT = 22;

  const LANE_COLORS = ['#ff6b9d', '#ff9e6b', '#ffd86b', '#a8ff6b', '#6bf0ff', '#7b96ff', '#b07bff', '#ff7bf0', '#ff8080', '#80ffd4', '#d4a0ff'];
  const LANE_NOTE_LABELS = ['Do', 'Re', 'Mi', 'Fa', 'Sol', 'La', 'Si', "Do'", "Re'", "Mi'", "Fa'"];

  // Disposición maestra alrededor de la barra espaciadora.
  // Orden físico: izquierda (más externa -> más interna), espacio, derecha (más interna -> más externa).
  const MASTER_KEYS = [
    { code: 'KeyQ', label: 'Q' },
    { code: 'KeyA', label: 'A' },
    { code: 'KeyS', label: 'S' },
    { code: 'KeyD', label: 'D' },
    { code: 'KeyF', label: 'F' },
    { code: 'Space', label: 'Esp' },
    { code: 'KeyJ', label: 'J' },
    { code: 'KeyK', label: 'K' },
    { code: 'KeyL', label: 'L' },
    { code: 'Semicolon', label: ';' },
    { code: 'Quote', label: "'" },
  ];
  // Primera mitad (sin contar espacio) = izquierda, segunda = derecha.
  const LEFT_MASTER = MASTER_KEYS.slice(0, 5); // Q A S D F
  const RIGHT_MASTER = MASTER_KEYS.slice(6);    // J K L ; '
  const SPACE_MASTER = MASTER_KEYS[5];

  // Construye la lista ordenada de teclas para N carriles (expandiendo desde el centro).
  function activeKeys(n) {
    n = Math.max(1, Math.min(11, n));
    if (n === 1) return [SPACE_MASTER];
    const keys = [];
    if (n % 2 === 0) {
      const k = n / 2;
      // izquierda: las k más internas (F,D,...); derecha: las k más internas (J,K,...)
      // queremos de más externa a más interna: slice ya interno? LEFT_MASTER está externa->interna, así que últimas k son las internas.
      const leftOrdered = LEFT_MASTER.slice(LEFT_MASTER.length - k); // internas, externa->interna? F is last; para 2: D,F (D externa, F interna) correcto
      const rightOrdered = RIGHT_MASTER.slice(0, k); // J,K,... interna->externa correcto
      return leftOrdered.concat(rightOrdered);
    }
    const k = (n - 1) / 2;
    const leftOrdered = LEFT_MASTER.slice(LEFT_MASTER.length - k);
    const rightOrdered = RIGHT_MASTER.slice(0, k);
    return leftOrdered.concat([SPACE_MASTER], rightOrdered);
  }

  let currentKeyMap = {}; // code -> lane index
  let currentKeyLabels = []; // label por carril

  function rebuildKeyMap(n) {
    const keys = activeKeys(n);
    currentKeyMap = {};
    currentKeyLabels = keys.map((k) => k.label);
    keys.forEach((k, i) => { currentKeyMap[k.code] = i; });
    // Dígitos/numpad: asignan al carril por posición visual (solo si existe).
    for (let i = 0; i < keys.length && i < 9; i++) {
      currentKeyMap['Digit' + (i + 1)] = i;
      currentKeyMap['Numpad' + (i + 1)] = i;
    }
  }

  const $ = (id) => document.getElementById(id);
  const ui = {
    score: $('m-score'), combo: $('m-combo'), acc: $('m-acc'), bestCombo: $('m-bestcombo'),
    health: $('m-health'), judgment: $('m-judgment'), comboBig: $('m-combobig'),
    overlay: $('m-overlay'), overlayTitle: $('m-overlay-title'), overlayText: $('m-overlay-text'),
    overlayStart: $('m-overlay-start'), result: $('m-result'), resultStats: $('m-result-stats'),
    resultRetry: $('m-result-retry'), startBtn: $('m-start'), restartBtn: $('m-restart'),
    lanesSelect: $('m-lanes'),
  };

  function laneCount() { return Math.max(1, Math.min(9, Number(ui.lanesSelect.value) || 4)); }

  // default 4 carriles (D F J K)
  if (ui.lanesSelect) ui.lanesSelect.value = '4';

  let phase = 'menu'; // menu | playing | result
  let lastFrameTime = 0;
  let notes = [];
  let audioStart = 0;
  let score = 0;
  let combo = 0;
  let maxCombo = 0;
  let totalPoints = 0;
  let noteCount = 0;
  let health = 100;
  let misses = 0;
  let counts = { PERFECT: 0, GREAT: 0, GOOD: 0, BAD: 0, MISS: 0 };
  let pressed = new Set();
  let missIndex = 0;
  let renderIndex = 0;
  let laneFlash = [];
  let rafId = null;
  let lastJudgment = null;
  let judgmentTimer = 0;
  let comboBigTimer = 0;

  function resetState() {
    const lanes = laneCount();
    rebuildKeyMap(lanes);
    notes = [];
    score = 0; combo = 0; maxCombo = 0; totalPoints = 0; noteCount = 0;
    health = 100; misses = 0;
    counts = { PERFECT: 0, GREAT: 0, GOOD: 0, BAD: 0, MISS: 0 };
    pressed = new Set();
    laneFlash = new Array(lanes).fill(0);
    missIndex = 0;
    renderIndex = 0;
  }

  async function startGame() {
    resetState();
    const ac = A.getContext();
    try { await ac.resume(); } catch (e) { /* ignore */ }
    const lanes = laneCount();
    const chart = L.generateChart({ bpm: 144, duration: 45, lanes: lanes, startTime: 2.0 });
    notes = chart.map((n) => ({ ...n, judged: false, judgment: null }));
    noteCount = notes.length;
    missIndex = 0;
    renderIndex = 0;

    ui.overlay.classList.add('hidden');
    ui.result.classList.add('hidden');
    ui.overlay.style.opacity = '1';
    ui.overlay.style.pointerEvents = '';
    if (ui.overlayStart) ui.overlayStart.style.display = '';

    audioStart = ac.currentTime + 1.5;
    A.scheduleBacking(chart, audioStart, 120);

    phase = 'playing';
    updateHud();
    if (rafId) cancelAnimationFrame(rafId);
    lastFrameTime = performance.now();
    rafId = requestAnimationFrame(loop);
  }

  function elapsed() { return A.getContext().currentTime - audioStart; }
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));

  function endGame() {
    phase = 'result';
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
    const acc = L.accuracyPercent(totalPoints, noteCount);
    ui.resultStats.innerHTML =
      `Puntos: <strong>${score}</strong><br>` +
      `Precisión: <strong>${acc.toFixed(2)}%</strong><br>` +
      `Mejor combo: <strong>${maxCombo}</strong><br>` +
      `Teclas: <strong>${laneCount()}</strong><br>` +
      `Perfect: ${counts.PERFECT} · Great: ${counts.GREAT} · Good: ${counts.GOOD} · Bad: ${counts.BAD} · Miss: ${counts.MISS}`;
    ui.result.classList.remove('hidden');
  }

  async function pauseGame() {
    if (phase !== 'playing') return;
    phase = 'paused';
    if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
    try { await A.getContext().suspend(); } catch (e) { /* ignore */ }
    ui.overlayTitle.textContent = 'Pausado';
    ui.overlayText.textContent = 'Pulsa Esc para continuar';
    if (ui.overlayStart) ui.overlayStart.style.display = 'none';
    ui.overlay.style.opacity = '1';
    ui.overlay.classList.remove('hidden');
  }

  async function countdownResume() {
    if (phase !== 'paused') return;
    phase = 'countdown';
    ui.overlay.style.opacity = '0.25';
    ui.overlay.style.pointerEvents = 'none';
    for (let i = 3; i >= 1; i--) {
      if (phase !== 'countdown') return;
      ui.overlayTitle.textContent = 'Reanudando...';
      ui.overlayText.textContent = i + '...';
      if (ui.overlayStart) ui.overlayStart.style.display = 'none';
      await wait(1000);
    }
    if (phase !== 'countdown') return;
    try { await A.getContext().resume(); } catch (e) { /* ignore */ }
    phase = 'playing';
    ui.overlay.classList.add('hidden');
    ui.overlay.style.opacity = '1';
    ui.overlay.style.pointerEvents = '';
    lastFrameTime = performance.now();
    if (rafId) cancelAnimationFrame(rafId);
    rafId = requestAnimationFrame(loop);
  }

  function cancelResume() {
    if (phase !== 'countdown') return;
    phase = 'paused';
    ui.overlayTitle.textContent = 'Pausado';
    ui.overlayText.textContent = 'Pulsa Esc para continuar';
    if (ui.overlayStart) ui.overlayStart.style.display = 'none';
    ui.overlay.style.opacity = '1';
    ui.overlay.style.pointerEvents = '';
    ui.overlay.classList.remove('hidden');
  }

  function updateHud() {
    ui.score.textContent = score;
    ui.combo.textContent = combo;
    ui.acc.textContent = L.accuracyPercent(totalPoints, noteCount).toFixed(1) + '%';
    ui.bestCombo.textContent = maxCombo;
    ui.health.style.width = health + '%';
  }

  function showJudgment(name) {
    lastJudgment = name;
    judgmentTimer = 0.9;
    ui.judgment.textContent = name;
    ui.judgment.className = 'judgment show ' + name;
    if (combo >= 10 && (name === 'PERFECT' || name === 'GREAT')) {
      comboBigTimer = 1.0;
      ui.comboBig.textContent = combo + 'x';
      ui.comboBig.classList.add('show');
    }
  }

  function tryHit(lane) {
    if (phase !== 'playing') return;
    const lanes = laneCount();
    if (lane < 0 || lane >= lanes) return;
    const now = elapsed();
    const candidates = notes.filter((n) => !n.judged && n.lane === lane && Math.abs(n.time - now) <= L.MISS_WINDOW);
    if (!candidates.length) {
      laneFlash[lane] = 0.25;
      return;
    }
    let best = candidates[0];
    let bestDelta = Math.abs(best.time - now);
    for (const n of candidates) {
      const d = Math.abs(n.time - now);
      if (d < bestDelta) { best = n; bestDelta = d; }
    }
    const jud = L.judge(best.time - now);
    best.judged = true;
    best.judgment = jud.name;
    const points = jud.name === 'MISS' ? 0 : jud.points;
    score += points;
    totalPoints += points;
    counts[jud.name] = (counts[jud.name] || 0) + 1;
    if (jud.name === 'MISS') {
      combo = 0;
      misses++;
    } else {
      if (jud.name === 'BAD') combo = 0; else combo += 1;
      if (combo > maxCombo) maxCombo = combo;
    }
    health = L.clampHealth(health + L.healthDelta(jud.name));
    showJudgment(jud.name);
    A.hitsound(jud.name);
    laneFlash[lane] = 0.3;
    updateHud();
    if (health <= 0) endGame();
  }

  function processMisses() {
    const now = elapsed();
    while (missIndex < notes.length) {
      const n = notes[missIndex];
      if (n.judged) { missIndex++; continue; }
      if (now - n.time > L.MISS_WINDOW) {
        n.judged = true;
        n.judgment = 'MISS';
        counts.MISS++;
        misses++;
        combo = 0;
        health = L.clampHealth(health + L.healthDelta('MISS'));
        A.hitsound('MISS');
        updateHud();
        missIndex++;
        if (health <= 0) { endGame(); return; }
      } else {
        break; // notas ordenadas por tiempo
      }
    }
  }

  function loop(ts) {
    if (phase !== 'playing') return;
    const dt = Math.min(0.05, lastFrameTime ? (ts - lastFrameTime) / 1000 : 0.016);
    lastFrameTime = ts;

    const now = elapsed();
    processMisses();
    if (phase !== 'playing') return;

    const lastNote = notes.length ? notes[notes.length - 1] : null;
    const endAt = lastNote ? lastNote.time + 2.0 : 5;
    if (now >= endAt) { endGame(); return; }

    judgmentTimer = Math.max(0, judgmentTimer - dt);
    if (judgmentTimer <= 0) ui.judgment.classList.remove('show');
    comboBigTimer = Math.max(0, comboBigTimer - dt);
    if (comboBigTimer <= 0) ui.comboBig.classList.remove('show');
    const lanes = laneCount();
    for (let i = 0; i < lanes; i++) laneFlash[i] = Math.max(0, (laneFlash[i] || 0) - dt);

    render();
    rafId = requestAnimationFrame(loop);
  }

  function render() {
    const now = elapsed();
    const lanes = laneCount();
    const lw = WIDTH / lanes;
    ctx2.clearRect(0, 0, WIDTH, HEIGHT);

    const grad2 = ctx2.createLinearGradient(0, 0, 0, HEIGHT);
    grad2.addColorStop(0, '#0b0d12');
    grad2.addColorStop(1, '#151822');
    ctx2.fillStyle = grad2;
    ctx2.fillRect(0, 0, WIDTH, HEIGHT);

    // lane flashes
    for (let i = 0; i < lanes; i++) {
      if ((laneFlash[i] || 0) > 0) {
        ctx2.fillStyle = 'rgba(255,255,255,' + (laneFlash[i] * 0.35) + ')';
        ctx2.fillRect(i * lw, 0, lw, HEIGHT);
      }
    }

    // separators
    ctx2.strokeStyle = 'rgba(255,255,255,0.08)';
    ctx2.lineWidth = 1;
    for (let i = 0; i <= lanes; i++) {
      ctx2.beginPath();
      ctx2.moveTo(i * lw, 0);
      ctx2.lineTo(i * lw, HEIGHT);
      ctx2.stroke();
    }

    // notes visibles (evita recorrer todas cada frame)
    while (renderIndex < notes.length) {
      const yr = JUDGMENT_Y - (notes[renderIndex].time - now) * NOTE_SPEED;
      if (yr > HEIGHT + 40) renderIndex++;
      else break;
    }
    for (let i = renderIndex; i < notes.length; i++) {
      const n = notes[i];
      const y = JUDGMENT_Y - (n.time - now) * NOTE_SPEED;
      if (y < -40) break; // siguientes aún más arriba
      if (n.judged) continue;
      const x = n.lane * lw + 3;
      const w = lw - 6;
      ctx2.fillStyle = LANE_COLORS[n.lane % LANE_COLORS.length];
      roundRect(ctx2, x, y - NOTE_HEIGHT / 2, w, NOTE_HEIGHT, 6);
      ctx2.fill();
      ctx2.fillStyle = 'rgba(255,255,255,0.35)';
      ctx2.fillRect(x + 2, y - NOTE_HEIGHT / 2 + 2, w - 4, 3);
    }

    // judgment line
    ctx2.strokeStyle = 'rgba(255,255,255,0.9)';
    ctx2.lineWidth = 3;
    ctx2.beginPath();
    ctx2.moveTo(0, JUDGMENT_Y);
    ctx2.lineTo(WIDTH, JUDGMENT_Y);
    ctx2.stroke();

    // key boxes
    ctx2.font = 'bold 12px system-ui';
    ctx2.textAlign = 'center';
    ctx2.textBaseline = 'middle';
    for (let i = 0; i < lanes; i++) {
      const cx = i * lw + lw / 2;
      const ky = JUDGMENT_Y + 14;
      ctx2.fillStyle = pressed.has(i) ? LANE_COLORS[i % LANE_COLORS.length] : 'rgba(255,255,255,0.15)';
      roundRect(ctx2, i * lw + 8, JUDGMENT_Y + 4, lw - 16, 38, 8);
      ctx2.fill();
      ctx2.fillStyle = '#fff';
      ctx2.fillText(currentKeyLabels[i], cx, ky - 6);
      ctx2.font = '10px system-ui';
      ctx2.fillStyle = 'rgba(255,255,255,0.7)';
      ctx2.fillText(LANE_NOTE_LABELS[i], cx, ky + 10);
      ctx2.font = 'bold 12px system-ui';
    }
  }

  function roundRect(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y);
    c.arcTo(x + w, y, x + w, y + h, r);
    c.arcTo(x + w, y + h, x, y + h, r);
    c.arcTo(x, y + h, x, y, r);
    c.arcTo(x, y, x + w, y, r);
    c.closePath();
  }

  function onKeyDown(e) {
    if (e.repeat) return;
    if (e.code === 'Escape') {
      e.preventDefault();
      if (phase === 'playing') pauseGame();
      else if (phase === 'paused') countdownResume();
      else if (phase === 'countdown') cancelResume();
      return;
    }
    const lane = currentKeyMap[e.code];
    if (lane === undefined) {
      if (e.code === 'Space' && laneCount() >= 1) {
        // handled by map if space active; otherwise ignore
      }
      return;
    }
    if (lane >= laneCount()) return;
    if (phase === 'playing') {
      e.preventDefault();
      pressed.add(lane);
      tryHit(lane);
    }
  }
  function onKeyUp(e) {
    const lane = currentKeyMap[e.code];
    if (lane === undefined) return;
    pressed.delete(lane);
  }

  document.addEventListener('keydown', onKeyDown);
  document.addEventListener('keyup', onKeyUp);

  canvas.addEventListener('pointerdown', (e) => {
    if (phase !== 'playing') return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const lanes = laneCount();
    const lane = Math.floor(x / (WIDTH / lanes));
    if (lane < 0 || lane >= lanes) return;
    pressed.add(lane);
    tryHit(lane);
    setTimeout(() => pressed.delete(lane), 120);
  });
  window.addEventListener('blur', () => pressed.clear());

  // Evitar scroll con espacio.
  window.addEventListener('keydown', (e) => { if (e.code === 'Space') e.preventDefault(); }, { passive: false });

  ui.overlayStart.addEventListener('click', startGame);
  ui.startBtn.addEventListener('click', () => {
    if (phase === 'playing') return;
    if (phase === 'result') ui.result.classList.add('hidden');
    startGame();
  });
  ui.restartBtn.addEventListener('click', () => {
    if (rafId) cancelAnimationFrame(rafId);
    phase = 'menu';
    ui.result.classList.add('hidden');
    ui.overlay.classList.remove('hidden');
  });
  ui.resultRetry.addEventListener('click', startGame);

  ui.lanesSelect.addEventListener('change', () => {
    if (phase === 'playing') startGame();
  });

  rebuildKeyMap(laneCount());
  ui.lanesSelect.value = String(laneCount() || 4);
  if (!ui.lanesSelect.value) ui.lanesSelect.value = '4';

  phase = 'menu';
  requestAnimationFrame(() => {
    ctx2.fillStyle = '#0b0d12';
    ctx2.fillRect(0, 0, WIDTH, HEIGHT);
  });
})();
