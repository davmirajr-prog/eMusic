const test = require('node:test');
const assert = require('node:assert');
const M = require('../js/mania-logic.js');

test('judge windows', () => {
  assert.strictEqual(M.judge(0).name, 'PERFECT');
  assert.strictEqual(M.judge(0.04).name, 'PERFECT');
  assert.strictEqual(M.judge(0.08).name, 'GREAT');
  assert.strictEqual(M.judge(0.12).name, 'GOOD');
  assert.strictEqual(M.judge(0.18).name, 'BAD');
  assert.strictEqual(M.judge(0.3).name, 'MISS');
});

test('healthDelta and clamp', () => {
  assert.strictEqual(M.healthDelta('MISS'), -20);
  assert.strictEqual(M.clampHealth(150), 100);
  assert.strictEqual(M.clampHealth(-5), 0);
});

test('generateChart basics', () => {
  const chart = M.generateChart({ bpm: 120, duration: 10, lanes: 8, startTime: 1, rand: () => 0.5 });
  assert.ok(Array.isArray(chart) && chart.length > 0);
  const ids = new Set(chart.map(n => n.id));
  assert.strictEqual(ids.size, chart.length);
  chart.forEach(n => {
    assert.ok(n.lane >= 0 && n.lane < 8);
    assert.ok(n.time >= 1 && n.time < 10);
    assert.ok(typeof n.midi === 'number');
  });
  // sorted by time
  for (let i = 1; i < chart.length; i++) assert.ok(chart[i].time >= chart[i-1].time);
});

test('accuracyPercent', () => {
  assert.strictEqual(M.accuracyPercent(3000, 10), 100);
  assert.strictEqual(M.accuracyPercent(0, 10), 0);
});
